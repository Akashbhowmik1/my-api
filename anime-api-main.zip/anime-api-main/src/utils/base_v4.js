export const v4_base_url = "9animetv.to";
