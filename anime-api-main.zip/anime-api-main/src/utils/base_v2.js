export const v2_base_url = "kaido.to";
